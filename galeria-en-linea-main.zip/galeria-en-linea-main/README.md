# galeria-en-linea
El objetivo de este  proyecto es la creación y configuración de una galería en línea, abordando aspectos técnicos como la configuración de DNS, el despliegue del backend en un servidor Nginx, la conexión cliente-servidor y el uso de Cloudflare para mejorar la seguridad y el rendimiento del sitio web. 

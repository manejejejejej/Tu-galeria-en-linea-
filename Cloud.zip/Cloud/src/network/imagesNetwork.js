const express = require('express')
const routes = express.Router();
const Controller = require("../controllers/imagesControllers")

function imagesNetwork(request, response) {
    const result = Controller.uploadImage()
    response.send(result);
}

routes.post("/upload", imagesNetwork)

module.exports = routes;
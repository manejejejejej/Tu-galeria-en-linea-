function onNewImage() {

}

module.exports = {
    onNewImage
}